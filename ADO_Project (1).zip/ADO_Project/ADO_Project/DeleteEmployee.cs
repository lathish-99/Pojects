﻿using ADO_Project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_Project
{
    public partial class DeleteEmployee : Form
    {
        Logic ob;
        public DeleteEmployee()
        {
            InitializeComponent();
            ob = new Logic();
        }

        private void DeleteEmployee_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();
            dataGridView1.Visible = false;
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(tbeid.Text);   
            bool es = ob.check(id);
            if (es)
            {
                string msg = ob.deletesp(id);
                if (msg != null)
                {
                    MessageBox.Show(msg);
                    dataGridView1.Visible = true;
                    dataGridView1.DataSource = ob.getAllData();
                }
                else
                {
                    MessageBox.Show("unable to fetch data....");
                }
            }
            else
            {
                MessageBox.Show("Enter valid EmpID");

            }
        }
    }
}
