﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_Project.Model
{
    class Logic
    {
        private string constr = ConfigurationManager.ConnectionStrings["adodb"].ConnectionString;

        //Inserting Values in Employee Table
        public List<Employee> getAllData()
        {
            List<Employee> li = new List<Employee>();
            string sql = "select * from employee";
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                while (sqr.Read())
                {
                    Employee ob = new Employee();
                    ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                    ob.Empname = sqr.GetValue(1).ToString();
                    ob.DOB = sqr.GetValue(2).ToString();
                    ob.Phone = Convert.ToInt64(sqr.GetValue(3));
                    ob.Email = sqr.GetValue(4).ToString();
                    ob.Salary = float.Parse(sqr.GetValue(5).ToString());
                    ob.Deptid = Convert.ToInt32(sqr.GetValue(6));
                    li.Add(ob);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return li;
        }

        public string addsp(Employee emp)
        {
            string message = null;
            string sql = "SPInsertEmployee";
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@eid", SqlDbType.Int).Value = emp.Empid;
                cmd.Parameters.Add("@ename", SqlDbType.VarChar, 50).Value = emp.Empname;
                cmd.Parameters.Add("@dob", SqlDbType.VarChar, 50).Value = emp.DOB;
                cmd.Parameters.Add("@phone", SqlDbType.BigInt).Value = emp.Phone;
                cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = emp.Email;
                cmd.Parameters.Add("@salary", SqlDbType.Float).Value = emp.Salary;
                cmd.Parameters.Add("@did", SqlDbType.Int).Value = emp.Deptid;
                cmd.ExecuteNonQuery();

                message = "Data Inserted Successfully";
            }
            catch (Exception)
            {
                message = "Couldn't insert the data!!";
            }
            finally
            {
                conn.Close();
            }
            return message;
        }

        //Inserting Values in department Table
        public List<Department> getAllDataDept()
        {
            List<Department> li = new List<Department>();
            string sql = "select * from department";
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                while (sqr.Read())
                {
                    Department ob = new Department();
                    ob.Deptid = Convert.ToInt32(sqr.GetValue(0));
                    ob.Deptname = sqr.GetValue(1).ToString();
                    ob.Deptlocation = sqr.GetValue(2).ToString(); 
                    ob.Managerid = Convert.ToInt32(sqr.GetValue(3));
                    li.Add(ob);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return li;
        }

        public string addspDept(Department d)
        {
            string message = null;
            string sql = "SPInsertDept";
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@did", SqlDbType.Int).Value = d.Deptid;
                cmd.Parameters.Add("@dname", SqlDbType.VarChar, 50).Value = d.Deptname;
                cmd.Parameters.Add("@dloc", SqlDbType.VarChar,50).Value = d.Deptlocation;
                cmd.Parameters.Add("@mid", SqlDbType.Int).Value = d.Managerid;
                cmd.ExecuteNonQuery();

                message = "Data Inserted Successfully";
            }
            catch (Exception)
            {
                message = "Couldn't insert the data!!";
            }
            finally
            {
                conn.Close();
            }
            return message;
        }

        //Search by Employee Name
        public Employee searchName(string name)
        {
            Employee ob = new Employee();            
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from employee where empname = '"+ name +"' " ;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                        ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.Empname = sqr.GetValue(1).ToString();
                        ob.DOB = sqr.GetValue(2).ToString();
                        ob.Phone = Convert.ToInt64(sqr.GetValue(3));
                        ob.Email = sqr.GetValue(4).ToString();
                        ob.Salary = float.Parse(sqr.GetValue(5).ToString());
                        ob.Deptid = Convert.ToInt32(sqr.GetValue(6));
                    }
                }
                else
                {
                    ob = null;
                }

            }
            catch (Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }

        //Search by Employee salary
        public Employee searchSalary(float sal)
        {
            string sql = "select * from employee where salary =" + sal;
            SqlConnection conn = new SqlConnection(constr);
            Employee ob = new Employee();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                        ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.Empname = sqr.GetValue(1).ToString();
                        ob.DOB = sqr.GetValue(2).ToString();
                        ob.Phone = Convert.ToInt64(sqr.GetValue(3));
                        ob.Email = sqr.GetValue(4).ToString();
                        ob.Salary = float.Parse(sqr.GetValue(5).ToString());
                        ob.Deptid = Convert.ToInt32(sqr.GetValue(6));

                    }
                }
                else
                {
                    ob = null;
                }

            }
            catch (Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }

        //Search by Employee ID
        public Employee search(int id)
        {
            string sql = "select * from employee where empid=" + id;
            SqlConnection conn = new SqlConnection(constr);
            Employee ob = new Employee();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                if (sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                        ob.Empid = Convert.ToInt32(sqr.GetValue(0));
                        ob.Empname = sqr.GetValue(1).ToString();
                        ob.DOB = sqr.GetValue(2).ToString();
                        ob.Phone = Convert.ToInt64(sqr.GetValue(3));
                        ob.Email = sqr.GetValue(4).ToString();
                        ob.Salary = float.Parse(sqr.GetValue(5).ToString());
                        ob.Deptid = Convert.ToInt32(sqr.GetValue(6));

                    }
                }
                else
                {
                    ob = null;
                }

            }
            catch (Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }


        //Update Employee 
        public void updatesp(Employee emp)
        {
            string sql = "spupdate";
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@eid", SqlDbType.Int).Value = emp.Empid;
                cmd.Parameters.Add("@ename", SqlDbType.VarChar, 50).Value = emp.Empname;
                cmd.Parameters.Add("@dob", SqlDbType.VarChar, 50).Value = emp.DOB;
                cmd.Parameters.Add("@phone", SqlDbType.BigInt).Value = emp.Phone;
                cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = emp.Email;
                cmd.Parameters.Add("@salary", SqlDbType.Float).Value = emp.Salary;
                cmd.Parameters.Add("@did", SqlDbType.Int).Value = emp.Deptid;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data Updated Successfully!!");
            }
            catch (Exception)
            {
                MessageBox.Show("Couldn't update the data!!");
            }
            finally
            {
                conn.Close();
            }
        }

        // Delete Employee
        public bool check(int id)
        {
            bool x = false;
            string sql = "select * from Employee where EMPID=" + id;
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                SqlCommand cmdd = new SqlCommand(sql, conn);
                SqlDataReader sqrr = cmdd.ExecuteReader();
                if (sqrr.HasRows)
                {
                    x = true;
                }
                else
                {
                    x = false;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Couldn't find data");
            }
            finally
            {
                conn.Close();
            }
            return x;
        }

        public string deletesp(int id)
        {
            string msg = "";
            string sql = "SPDeleteEmployee";
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EMPID", id);
                cmd.ExecuteNonQuery();
                msg = "Data Deleted Successfully";
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot delete the data");
            }
            finally
            {
                conn.Close();
            }
            return msg;
        }

        //Details Of Manager
        public DataTable DetailsOfManager()
        {
            DataTable dt = new DataTable("join");
            string sql = "select e.empid,e.empname,d.deptname,d.deptlocation from employee e inner join department d on e.deptid=d.deptid and deptname='Robotics' ";
            SqlConnection conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql,conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);

            }
            catch (Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return dt;
        }
    }
}
