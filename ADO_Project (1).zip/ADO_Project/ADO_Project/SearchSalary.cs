﻿using ADO_Project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_Project
{
    public partial class SearchSalary : Form
    {
        Logic ob;
        public SearchSalary()
        {
            InitializeComponent();
            ob = new Logic();
        }

        private void SearchSalary_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            float sal = float.Parse(tbsalary.Text);
            Employee emp = ob.searchSalary(sal);
            if (emp == null)
            {
                MessageBox.Show("NO Data Present");
            }
            else
            {
                List<Employee> li = new List<Employee>();
                li.Add(emp);
                MessageBox.Show("Data is Present");
                dataGridView1.Visible = true;
                dataGridView1.DataSource = li;
            }
            tbsalary.Text = "";
        }
    }
}
