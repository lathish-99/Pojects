﻿using ADO_Project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_Project
{
    public partial class InsertDept : Form
    {
        Logic ob;
        public InsertDept()
        {
            InitializeComponent();
            ob = new Logic();
        }

        private void InsertDept_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllDataDept();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Department d = new Department();
            d.Deptid = Convert.ToInt32(tbdid.Text);
            d.Deptname = tbdname.Text.ToString();
            d.Deptlocation = tbloc.Text.ToString();
            d.Managerid = Convert.ToInt32(tbeid.Text);

            string msg = ob.addspDept(d);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getAllDataDept();
            tbdid.Text = "";
            tbdname.Text = "";
            tbloc.Text = "";
            tbeid.Text = "";
        }

        private void tbloc_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbdname_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbeid_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbdid_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
