﻿using ADO_Project.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_Project
{
    public partial class UpdateEmployee : Form
    {
        Logic ob;
        public UpdateEmployee()
        {
            InitializeComponent();
            ob = new Logic();
        }

        private void UpdateEmployee_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            tbename.Visible = false;
            tbdob.Visible = false;
            tbphone.Visible = false;
            tbemail.Visible = false;
            tbsalary.Visible = false;
            tbdid.Visible = false;
            btnupdate.Visible = false;
        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(tbeid.Text);
            Employee emp = ob.search(id);
            if (emp == null)
            {
                MessageBox.Show("Enter the valid EMPID as this doesn't exists");
            }
            else
            {
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                label7.Visible = true;
                tbename.Visible = true;
                tbdob.Visible = true;
                tbphone.Visible = true;
                tbemail.Visible = true;
                tbsalary.Visible = true;
                tbdid.Visible = true;
                btnupdate.Visible = true;

            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

            Employee emp = new Employee();
            emp.Empid = Convert.ToInt32(tbeid.Text);
            emp.Empname = tbename.Text.ToString();
            emp.DOB = tbdob.Text.ToString();
            emp.Phone= Convert.ToInt64(tbphone.Text);
            emp.Email = tbemail.Text.ToString();
            emp.Salary=float.Parse(tbsalary.Text);
            emp.Deptid = Convert.ToInt32(tbdid.Text);

            ob.updatesp(emp);

        
            tbeid.Text = "";
            tbename.Text = "";
            tbdob.Text = "";
            tbphone.Text = "";
            tbemail.Text = "";
            tbsalary.Text = "";
            tbdid.Text = "";

            dataGridView1.DataSource = ob.getAllData();

            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            tbename.Visible = false;
            tbdob.Visible = false;
            tbphone.Visible = false;
            tbemail.Visible = false;
            tbsalary.Visible = false;
            tbdid.Visible = false;
            btnupdate.Visible = false;
            btncheck.Visible = true;
        }
    }
}
